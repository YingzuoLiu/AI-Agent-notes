"""
Conversational Personalized Recommendation – LangChain Skeleton
===============================================================
Goal
----
A minimal, production-lean skeleton for a *conversational* recommender using LangChain.
It demonstrates:
  • Sequential chaining (prompt → model → parser)
  • Branching/routing (clarify vs. recommend)
  • Dataflow (explicit dict keys)
  • Context passing (simple session memory)
  • Observability (callbacks + run_name)
  • Fallback patterns & where to place retries / rollback

This file is intentionally light on external deps and ready to extend.

Quickstart
----------
1) `pip install langchain langchain-openai`  (or a recent LangChain version)
2) Export `OPENAI_API_KEY` in your environment
3) Run: `python conversational_recsys_skeleton.py`

Notes
-----
• We keep retrieval/re-ranking as stubs to swap with your real vector DB & model.
• We highlight where to add retries (temporary errors) and rollback/compensation (write-side).
"""

from __future__ import annotations
import os
import json
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

# ==== LangChain imports with compatibility fallbacks ====
try:
    from langchain_openai import ChatOpenAI  # modern integration package
except Exception:
    # older LangChain versions
    from langchain.chat_models import ChatOpenAI  # type: ignore

try:
    from langchain.prompts import ChatPromptTemplate
except Exception:
    # very old versions
    from langchain import PromptTemplate as ChatPromptTemplate  # type: ignore

try:
    from langchain_core.output_parsers import StrOutputParser
except Exception:
    from langchain.output_parsers import StrOutputParser  # type: ignore

try:
    from langchain_core.runnables import (
        RunnableLambda,
        RunnablePassthrough,
        RunnableBranch,
        RunnableMap,
    )
except Exception:
    from langchain.schema.runnable import (  # type: ignore
        RunnableLambda,
        RunnablePassthrough,
        RunnableBranch,
        RunnableMap,
    )

# ==== Simple in-memory session memory ====
_SESSION_STORE: Dict[str, Dict[str, Any]] = {}


def _get_session(session_id: str) -> Dict[str, Any]:
    if session_id not in _SESSION_STORE:
        _SESSION_STORE[session_id] = {
            "history": [],  # list of {role, content}
            "profile": {},  # simple user prefs aggregation
        }
    return _SESSION_STORE[session_id]


# ==== Observability: lightweight callback handler ====
try:
    from langchain.callbacks.base import BaseCallbackHandler
except Exception:
    BaseCallbackHandler = object  # fallback noop


class SimpleTrace(BaseCallbackHandler):
    def __init__(self, name: str = "trace"):
        self.name = name
        self.t0 = 0.0
        self.tokens = 0

    # LLM lifecycle hooks
    def on_llm_start(self, serialized, prompts, **kwargs):  # type: ignore
        self.t0 = time.time()
        head = prompts[0][:160] if prompts else ""
        print(f"[LLM-START:{self.name}] {head}…")

    def on_llm_new_token(self, token: str, **kwargs):  # type: ignore
        self.tokens += 1
        # Stream tokens to console (optional)
        # print(token, end="", flush=True)

    def on_llm_end(self, response, **kwargs):  # type: ignore
        dt = time.time() - self.t0
        print(f"[LLM-END:{self.name}] elapsed={dt:.2f}s tokens≈{self.tokens}")
        self.tokens = 0

    def on_llm_error(self, error: Exception, **kwargs):  # type: ignore
        print(f"[LLM-ERROR:{self.name}] {error}")


# ==== Models (primary + fallback) ====
PRIMARY_MODEL = os.getenv("PRIMARY_MODEL", "gpt-4o-mini")
FALLBACK_MODEL = os.getenv("FALLBACK_MODEL", "gpt-4o-mini")  # change to a cheaper/stabler if needed

primary_llm = ChatOpenAI(
    model=PRIMARY_MODEL,
    temperature=0.2,
    max_retries=2,  # temporary-error retries at the model layer
)

fallback_llm = ChatOpenAI(
    model=FALLBACK_MODEL,
    temperature=0.2,
    max_retries=2,
)

# ==== Fake catalog (swap with your DB / vector store) ====
CATALOG: List[Dict[str, Any]] = [
    {"id": "m1", "title": "Inception", "genres": ["Sci-Fi", "Thriller"], "year": 2010},
    {"id": "m2", "title": "Interstellar", "genres": ["Sci-Fi", "Drama"], "year": 2014},
    {"id": "m3", "title": "The Dark Knight", "genres": ["Action"], "year": 2008},
    {"id": "m4", "title": "La La Land", "genres": ["Romance", "Music"], "year": 2016},
    {"id": "m5", "title": "Whiplash", "genres": ["Drama", "Music"], "year": 2014},
]


# ==== Prompt templates ====
intent_prompt = ChatPromptTemplate.from_messages([
    ("system",
     "你是推荐系统的意图理解器。基于用户输入和部分历史，\n"
     "抽取：intent(如 recommend/clarify)，query(5-10字), genres(数组，可空)，\n"
     "constraints(如年份/预算，可空)，needs_clarification(布尔)。\n"
     "严格输出JSON，字段为: intent, query, genres, constraints, needs_clarification。"),
    ("human",
     "用户话术：{user_input}\n"
     "历史偏好：{profile}\n"
     "历史对话片段：{history}\n"
     ),
])

clarify_prompt = ChatPromptTemplate.from_messages([
    ("system",
     "你是澄清问题生成器。找出最关键的一点不确定性，提出1个简短的问题。"),
    ("human", "用户话术：{user_input}\n当前理解：{draft}\n历史：{history}")
])

explain_prompt = ChatPromptTemplate.from_messages([
    ("system",
     "你是推荐解释器。给每个条目产出一句理由(≤20字)，口吻自然。严格输出JSON数组，与输入items顺序一一对应。"),
    ("human",
     "用户偏好：{profile}\n候选条目：{items}\n请输出JSON数组，如：[\"理由1\",\"理由2\",...]\n")
])

# ==== Parsers ====
str_parser = StrOutputParser()


# ==== Helpers ====
def _safe_json_loads(text: str) -> Optional[Any]:
    try:
        return json.loads(text)
    except Exception:
        return None


def _need_clarification(parsed: Dict[str, Any]) -> bool:
    return bool(parsed.get("needs_clarification"))


# ==== Retrieval (stub) ====
def retrieve_candidates(query: str, genres: List[str], topk: int = 10) -> List[Dict[str, Any]]:
    """Replace with your retriever (vector DB / BM25 / hybrid). Here: trivial filter+match."""
    q = (query or "").lower()
    gset = set([g.lower() for g in genres or []])
    scored: List[Tuple[float, Dict[str, Any]]] = []
    for item in CATALOG:
        score = 0.0
        title = item["title"].lower()
        if q and q in title:
            score += 1.0
        if gset:
            overlap = len(gset.intersection([x.lower() for x in item.get("genres", [])]))
            score += 0.5 * overlap
        scored.append((score, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [it for s, it in scored[:topk]] or CATALOG[:min(topk, len(CATALOG))]


# ==== Re-ranking (stub) ====
def rerank(items: List[Dict[str, Any]], profile: Dict[str, Any], topk: int = 5) -> List[Dict[str, Any]]:
    """Replace with your learned scorer (LightGBM / cross-encoder / LLM reranker)."""
    pref_genres = set([g.lower() for g in profile.get("fav_genres", [])])
    scored = []
    for it in items:
        g = set([x.lower() for x in it.get("genres", [])])
        score = len(pref_genres.intersection(g))  # very naive
        scored.append((score, it))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [it for s, it in scored[:topk]]


# ==== Logging (with compensation hook) ====
_LOG_STORE: List[Dict[str, Any]] = []  # pretend DB table


def write_log(record: Dict[str, Any]) -> bool:
    """Simulate a write with idempotency; return True/False. Add real DB + retries here."""
    # Idempotency by request_id
    rid = record.get("request_id")
    if any(r.get("request_id") == rid for r in _LOG_STORE):
        return True  # already written
    try:
        _LOG_STORE.append(record)
        return True
    except Exception:
        return False


def compensate_log(record: Dict[str, Any]) -> None:
    """Compensation: mark invalid or delete. Here we simply tag it."""
    rid = record.get("request_id")
    for r in _LOG_STORE:
        if r.get("request_id") == rid:
            r["valid"] = False
            r["compensated_at"] = time.time()
            return


# ==== Chains (LCEL-style) ====
trace_intent = SimpleTrace("intent")
trace_explain = SimpleTrace("explain")

intent_chain = (
    intent_prompt
    | primary_llm.with_config({"callbacks": [trace_intent], "run_name": "intent-primary"})
    | str_parser
)

intent_chain_fallback = (
    intent_prompt
    | fallback_llm.with_config({"callbacks": [trace_intent], "run_name": "intent-fallback"})
    | str_parser
)

# Router for intent: try primary → parse → if JSON bad, try fallback; if still bad, force clarify

def run_intent(user_input: str, profile: Dict[str, Any], history: List[Dict[str, str]]) -> Dict[str, Any]:
    payload = {"user_input": user_input, "profile": json.dumps(profile, ensure_ascii=False),
               "history": json.dumps(history[-6:], ensure_ascii=False)}

    text = intent_chain.invoke(payload)
    data = _safe_json_loads(text)
    if data is None:
        text2 = intent_chain_fallback.invoke(payload)
        data = _safe_json_loads(text2) or {
            "intent": "clarify", "query": "", "genres": [],
            "constraints": {}, "needs_clarification": True
        }
    return data


clarify_chain = (
    clarify_prompt
    | fallback_llm.with_config({"callbacks": [SimpleTrace("clarify")], "run_name": "clarify"})
    | str_parser
)


# Explain reasons for items (batched JSON array)
explain_chain = (
    explain_prompt
    | primary_llm.with_config({"callbacks": [trace_explain], "run_name": "explain"})
    | str_parser
)


# ==== Orchestrator ====
class Orchestrator:
    def __init__(self):
        self.primary = primary_llm
        self.fallback = fallback_llm

    def handle(self, session_id: str, user_input: str, topk: int = 5) -> Dict[str, Any]:
        sess = _get_session(session_id)
        sess["history"].append({"role": "user", "content": user_input})

        # [1] Intent understanding
        intent = run_intent(user_input, sess["profile"], sess["history"])

        if _need_clarification(intent):
            q = clarify_chain.invoke({
                "user_input": user_input,
                "draft": json.dumps(intent, ensure_ascii=False),
                "history": json.dumps(sess["history"][-6:], ensure_ascii=False),
            })
            sess["history"].append({"role": "assistant", "content": q})
            return {"type": "clarify", "question": q}

        # [2] Retrieval (temporary errors → add retries in your real impl)
        cands = retrieve_candidates(intent.get("query", ""), intent.get("genres", []), topk=20)

        # [3] Rerank
        ranked = rerank(cands, sess["profile"], topk=topk)

        # [4] Explain (structured reasons)
        items_json = json.dumps(ranked, ensure_ascii=False)
        reasons_text = explain_chain.invoke({
            "profile": json.dumps(sess["profile"], ensure_ascii=False),
            "items": items_json,
        })
        reasons = _safe_json_loads(reasons_text) or ["为你匹配的热门项"] * len(ranked)

        recs = []
        for i, it in enumerate(ranked):
            recs.append({"id": it["id"], "title": it["title"], "genres": it.get("genres", []),
                         "reason": reasons[i] if i < len(reasons) else "高相关候选"})

        # [5] Write log (idempotent + compensation hook if fails)
        request_id = str(uuid.uuid4())
        record = {"request_id": request_id, "session_id": session_id,
                  "input": user_input, "intent": intent, "recs": recs, "valid": True,
                  "ts": time.time()}

        ok = write_log(record)
        if not ok:
            # Compensation example (rollback-ish): mark invalid and queue for retry
            compensate_log(record)

        # Append assistant response into history for context passing
        sess["history"].append({"role": "assistant", "content": json.dumps(recs, ensure_ascii=False)})

        return {"type": "recommend", "items": recs, "request_id": request_id}


# ==== Demo main ====
if __name__ == "__main__":
    session = "demo-user-001"
    orch = Orchestrator()

    print("\n=== Round 1: vague ask ===")
    r1 = orch.handle(session, "给我推荐点好看的电影吧")
    print(json.dumps(r1, ensure_ascii=False, indent=2))

    if r1.get("type") == "clarify":
        print("\n=== Round 2: answer clarification ===")
        # user answers clarification; this would refine profile/history
        r2 = orch.handle(session, "我更喜欢科幻和音乐类的")
        print(json.dumps(r2, ensure_ascii=False, indent=2))

    print("\n=== Log snapshot (pretend DB) ===")
    print(json.dumps(_LOG_STORE[-1] if _LOG_STORE else {}, ensure_ascii=False, indent=2))
